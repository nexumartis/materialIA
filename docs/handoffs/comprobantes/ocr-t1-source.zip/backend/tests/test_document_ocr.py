"""OCR real (sin mocks) sobre comprobantes sintéticos generados acá: RapidOCR local, sin red.

Los textos se dibujan con Vera (incluida en reportlab, no depende de las fuentes de la PC).
Ninguna lectura acredita un pago: sólo se comprueban texto, campos sugeridos y rechazos.
"""
from __future__ import annotations

import io
from pathlib import Path

import pytest
import reportlab
from PIL import Image, ImageDraw, ImageFilter, ImageFont
from reportlab.lib import pdfencrypt
from reportlab.pdfgen import canvas

from app.documents import ocr

FONT = ImageFont.truetype(str(Path(reportlab.__file__).parent / "fonts" / "Vera.ttf"), 28)
RECEIPT = ["Comprobante de transferencia", "PAGO APROBADO", "Importe: $ 12.345,67",
           "Fecha: 24/10/2026 14:32", "N° de operación: 98765432101", "Destino: Grifería Demo SRL"]
EXPECTED = {"amount": "12345.67", "currency": "ARS", "date": "2026-10-24", "reference": "98765432101"}


def _image(lines: list[str]) -> Image.Image:
    img = Image.new("RGB", (900, 70 + 60 * len(lines)), "white")
    draw = ImageDraw.Draw(img)
    for i, text in enumerate(lines):
        draw.text((40, 30 + i * 60), text, fill="black", font=FONT)
    return img


def _encode(img: Image.Image, fmt: str, **kw) -> bytes:
    buf = io.BytesIO()
    img.save(buf, fmt, **kw)
    return buf.getvalue()


def _text_pdf(pages: list[list[str]], **kw) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, **kw)
    for lines in pages:
        for i, text in enumerate(lines):
            c.drawString(72, 760 - 22 * i, text)
        c.showPage()
    c.save()
    return buf.getvalue()


def _values(result: dict) -> dict:
    return {k: f["value"] for k, f in result["fields"].items()}


@pytest.mark.parametrize("fmt", ["PNG", "JPEG"])
def test_image_receipt(fmt):
    data = _encode(_image(RECEIPT), fmt, **({"quality": 70} if fmt == "JPEG" else {}))
    result = ocr.read_document(data)
    assert result["kind"] == fmt.lower()
    assert "operación" in " ".join(ln["text"] for ln in result["lines"])
    assert _values(result) == EXPECTED
    assert result["needs_review"] is False
    # «PAGO APROBADO» en la imagen es texto, no un estado: el resultado no tiene nada de pago.
    assert set(result) == {"kind", "pages", "lines", "fields", "needs_review", "engine"}


def test_digital_pdf_uses_text_layer():
    result = ocr.read_document(_text_pdf([RECEIPT]))
    assert {ln["source"] for ln in result["lines"]} == {"pdf_text"}
    assert _values(result) == EXPECTED


def test_scanned_pdf_is_ocrd():
    result = ocr.read_document(_encode(_image(RECEIPT), "PDF", resolution=150))
    assert {ln["source"] for ln in result["lines"]} == {"ocr"}
    assert _values(result) == EXPECTED


def test_mixed_pdf_text_page_and_scanned_page():
    header = _text_pdf([["Banco Demo - Resumen de operaciones del cliente", "Página de cortesía"]])
    scanned = _encode(_image(RECEIPT), "PDF", resolution=150)
    import pypdfium2 as pdfium
    merged = pdfium.PdfDocument.new()
    merged.import_pages(pdfium.PdfDocument(header))
    merged.import_pages(pdfium.PdfDocument(scanned))
    buf = io.BytesIO()
    merged.save(buf)
    result = ocr.read_document(buf.getvalue())
    assert result["pages"] == 2
    assert {(ln["page"], ln["source"]) for ln in result["lines"]} >= {(1, "pdf_text"), (2, "ocr")}
    assert _values(result) == EXPECTED


def test_two_different_amounts_stay_for_review():
    lines = ["Importe: $ 12.345,67", "Total debitado: $ 12.400,00", "Fecha: 24/10/2026",
             "N° de operación: 98765432101"]
    result = ocr.read_document(_encode(_image(lines), "PNG"))
    amount = result["fields"]["amount"]
    assert amount["value"] is None and set(amount["candidates"]) == {"12345.67", "12400.00"}
    assert result["fields"]["currency"]["value"] is None
    assert result["needs_review"] is True


@pytest.mark.parametrize("width, blur", [(300, 1.5), (180, 2)], ids=["parcial", "ilegible"])
def test_degraded_receipt_never_invents_values(width, blur):
    img = _image(RECEIPT)
    img = img.resize((width, img.height * width // img.width)).filter(ImageFilter.GaussianBlur(blur)).resize(img.size)
    result = ocr.read_document(_encode(img, "JPEG", quality=25))
    assert all(v in (None, EXPECTED[k]) for k, v in _values(result).items())
    assert result["fields"]["amount"]["value"] is None
    assert result["needs_review"] is True


@pytest.mark.parametrize("data, reason", [
    (b"GIF89a" + b"\0" * 100, "tipo no admitido"),
    (b"\x89PNG\r\n\x1a\n" + b"basura" * 50, "dañada"),
    (_encode(Image.new("L", (5000, 5000), 255), "PNG"), "MP"),
    (_text_pdf([["x"]], encrypt=pdfencrypt.StandardEncryption("clave", "dueño")), "contraseña"),
    (_text_pdf([RECEIPT])[:300], "dañado"),
    (_text_pdf([["página"]] * (ocr.MAX_PAGES + 1)), "páginas"),
    (b"%PDF-" + b"\0" * ocr.MAX_BYTES, "MiB"),
], ids=["gif", "png-falso", "bomba-25mp", "pdf-contraseña", "pdf-truncado", "pdf-6-paginas", "10mib"])
def test_rejections(data, reason):
    with pytest.raises(ocr.DocumentRejected, match=reason):
        ocr.read_document(data)


def test_timeout_kills_the_reader():
    with pytest.raises(ocr.OcrFailed, match="tiempo"):
        ocr.read_document(_encode(_image(RECEIPT), "PNG"), timeout=0.2)


def test_models_match_pinned_hashes():
    root = ocr.verify_models()
    assert all((root / name).is_file() for name, _ in ocr.MODELS.values())


@pytest.mark.parametrize("lines, expected", [
    (["Monto", "U$S 1.250,00", "ID de transacción", "MP-7788990011"],
     {"amount": "1250.00", "currency": "USD", "reference": "MP-7788990011"}),
    (["Total: 1,234.56", "Comprobante de transferencia"], {"amount": None, "reference": None}),
    (["Viernes, 24 de octubre de 2026", "Pagaste $ 980"], {"date": "2026-10-24", "amount": "980.00"}),
])
def test_field_parser(lines, expected):
    fields = ocr.suggest_fields([{"page": 1, "text": t, "score": 0.99} for t in lines])["fields"]
    assert {k: fields[k]["value"] for k in expected} == expected
