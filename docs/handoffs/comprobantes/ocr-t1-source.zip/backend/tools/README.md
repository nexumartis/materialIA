# OCR local de comprobantes

`app/documents/ocr.py` lee JPG/PNG/PDF y devuelve líneas, campos sugeridos (importe, moneda,
fecha y referencia), puntajes y `needs_review`. **Sólo extrae datos:** no acredita pagos ni cambia
pedidos, aunque el archivo diga «pagado» y el puntaje sea alto.

## Motor

- RapidOCR 3.10.0 + ONNX Runtime 1.31.0 en CPU (fijados en `pyproject.toml`).
- Modelos PP-OCRv6 small multilingües (incluyen español): detección y reconocimiento, **sin**
  clasificador de orientación. Vienen dentro del wheel de rapidocr; no se descarga nada.
  `ocr.MODELS` fija sus SHA256, los mismos que publica rapidocr en `default_models.yaml`. Si un
  archivo no coincide, el lector falla.
- Cada lectura corre en un subproceso con la red bloqueada, con tiempo máximo y de a uno por
  proceso. El texto del PDF se usa sin OCR; se renderizan las páginas escaneadas o que tienen imágenes.
- Windows necesita Microsoft Visual C++ Redistributable 2015+ x64, que pide onnxruntime.

## Límites de la demo

10 MiB por archivo · tipo por firma (JPG, PNG o PDF) · hasta 5 páginas · 20 MP por imagen o página
renderizada (200 dpi como máximo) · 60 s por lectura · un OCR a la vez por proceso. Se rechazan
los PDF con contraseña de apertura y los archivos dañados. Un PDF que sólo restringe permisos se lee.
Un campo con 0 o varios valores distintos queda en `null` con sus candidatos. También va a
revisión si el puntaje es menor que 0,90.

## Preparar y verificar

```bash
cd backend
pip install -e ".[dev]"
python -m tools.prepare_ocr                          # versiones, hashes y una lectura real sin red
python -m pytest -q tests/test_document_ocr.py      # comprobantes sintéticos, OCR real
```

Al igual que el resto de la suite, los tests se saltean si Postgres no responde (`conftest.py`).
Para correr sólo OCR sin base: `python -m pytest --noconftest tests/test_document_ocr.py`.
